ZoneOutMC Assets v2
Custom font: zoneoutmc:ui

Visible glyphs:
E100 ZoneOut
E101 Profile
E102 Account
E103 Points
E104 Coin
E105 Sword/Kills
E106 Skull/Deaths
E107 Trophy/Wins
E108 Clock/Playtime
E109 Server
E10A Ping

Spacing:
E000..E003 negative 1/2/4/8 px
E010..E015 positive 1/2/4/8/16/32 px

This pack does NOT replace vanilla block/item/entity textures.
