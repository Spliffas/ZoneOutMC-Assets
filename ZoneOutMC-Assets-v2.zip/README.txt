ZoneOutMC Assets v2
ZoneTAB custom font: zoneoutmc:ui

Spacing glyphs:
U+E000..E003 negative spacing
U+E010..E013 positive spacing

Bitmap glyphs:
U+E100 zone/shield
U+E101 profile
U+E102 coin
U+E103 account/key
