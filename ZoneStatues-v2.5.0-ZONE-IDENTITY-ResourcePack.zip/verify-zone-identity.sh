#!/usr/bin/env bash
set -euo pipefail
pack_dir="$(cd "$(dirname "$0")" && pwd)"
icons="$pack_dir/assets/zoneout/textures/font/zone_identity_icons.png"
divider="$pack_dir/assets/zoneout/textures/font/zone_identity_divider.png"
font="$pack_dir/assets/minecraft/font/default.json"
test -f "$icons"
test -f "$divider"
test "$(identify -format '%wx%h' "$icons")" = "120x12"
test "$(identify -format '%wx%h' "$divider")" = "120x2"
jq -e '[.providers[] | select(.file == "zoneout:font/zone_identity_icons.png")] | length == 1' "$font" >/dev/null
jq -e '[.providers[] | select(.file == "zoneout:font/zone_identity_divider.png")] | length == 1' "$font" >/dev/null
jq -e '[.providers[] | select(.type == "space") | .advances["\ue301"]] | any(. == 13)' "$font" >/dev/null
