ZoneOutMC Assets v3
- custom font: zoneoutmc:ui
- U+E110 = ZONEOUTMC logo
- U+E111 = ZONEOUT section label
- U+E112 = TAVO PROFILIS section label
- U+E113 = PASKYRA section label
- U+E102 = ZoneCoin icon
- existing spacing glyphs preserved
Built for ZoneTAB v4.0.0-alpha10.
