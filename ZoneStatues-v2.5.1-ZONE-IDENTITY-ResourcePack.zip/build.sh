#!/usr/bin/env bash
set -euo pipefail
project_dir="$(cd "$(dirname "$0")" && pwd)"
workspace_dir="$(dirname "$project_dir")"
build_dir="$project_dir/build-manual"
classes_dir="$build_dir/classes"
stubs_dir="$build_dir/stubs"
artifact="$project_dir/ZoneScoreboard-v2.5.1-ZONE-IDENTITY-FONT-FIX-Paper26.2.jar"
mkdir -p "$classes_dir" "$stubs_dir"
if command -v javac >/dev/null 2>&1; then compiler=(javac); release=21; else compiler=(java -m jdk.compiler/com.sun.tools.javac.Main); release=17; fi
"${compiler[@]}" --release "$release" -d "$stubs_dir" $(find "$project_dir/build-stubs" -name '*.java')
"${compiler[@]}" --release "$release" -encoding UTF-8 -cp "$stubs_dir:$workspace_dir/ZonePermissions/build-manual/classes" -d "$classes_dir" $(find "$project_dir/src/main/java" -name '*.java')
cp "$project_dir/src/main/resources/plugin.yml" "$classes_dir/plugin.yml"
cp "$project_dir/src/main/resources/config.yml" "$classes_dir/config.yml"
if command -v jar >/dev/null 2>&1; then jar --create --file "$artifact" -C "$classes_dir" .; else java -m jdk.jartool/sun.tools.jar.Main --create --file "$artifact" -C "$classes_dir" .; fi
printf '%s\n' "$artifact"
