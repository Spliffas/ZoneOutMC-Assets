# ZoneIdentity Scoreboard Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Atkurti patvirtinto žaidimo maketo ZoneIdentity turinį standartinio Minecraft sidebar viduje Paper 26.2 serveryje.

**Architecture:** ZoneScoreboard parenka kiekvienos eilutės fiksuoto pločio resource-pack glyphus ir tekstą. Grynos Java klasės aprašo HUD eilučių šabloną, glyphų kodus bei animacijos kadrus; pluginas tik įterpia žaidėjo ir ZonePermissions duomenis. Vienas bitmap atlasas laiko profilio, skirtukų ir grandine sujungtų ikonų variantus.

**Tech Stack:** Java 17, Paper 26.2 API, ZonePermissions API, Minecraft bitmap font JSON, PNG pixel art, YAML.

**Spec:** `docs/superpowers/specs/2026-09-14-zoneidentity-scoreboard-design.md`

## Global Constraints

- Minecraft sidebar išorinė forma ir fonas nekeičiami.
- ZoneScoreboard jungiasi tiesiai prie ZonePermissions ir nepriklauso nuo seno ZoneCore.
- Visi tekstai, spalvos, eilutės ir kosmetinių temų leidimai lieka YAML faile.
- Pirmoji veikianti tema yra `ZONE_CORE`; vėlesnėms temoms paliekama stabili temos ID struktūra.
- Tikra žaidėjo skin galva nenaudojama; rodomas custom Zone Avatar.

---

### Task 1: ZoneIdentity HUD modelis

**Files:**
- Create: `src/main/java/lt/zoneoutmc/scoreboard/ZoneIdentityHud.java`
- Create: `src/test/java/lt/zoneoutmc/scoreboard/ZoneIdentityHudTest.java`

**Interfaces:**
- Consumes: temos ID, animacijos tick ir ZonePermissions pateiktą rango tekstą.
- Produces: `static int glyph(Part part, int frame)` ir stabilų `Part` enumą profiliui, skirtukams bei penkioms HUD ikonoms.

- [ ] **Step 1: Write the failing test**

Testas patikrina, kad `ZONE_CORE` profilio glyphas, viršutinis ir apatinis skirtukai bei XP/monetų/prisijungusių/serverio/laiko ikonų glyphai nesikerta, o laikrodis turi keturis animacijos kadrus.

- [ ] **Step 2: Run test to verify it fails**

Run: `java -m jdk.compiler/com.sun.tools.javac.Main --release 17 ... ZoneIdentityHudTest.java`
Expected: FAIL, nes `ZoneIdentityHud` dar neegzistuoja.

- [ ] **Step 3: Write minimal implementation**

Sukurti `ZoneIdentityHud` su privačių Unicode kodų baze `U+E300`, `Part` enumu ir `Math.floorMod(frame, frames)` parinkimu.

- [ ] **Step 4: Run test to verify it passes**

Run: kompiliuoti klasę ir testą, tada paleisti `lt.zoneoutmc.scoreboard.ZoneIdentityHudTest`.
Expected: PASS.

### Task 2: ZoneIdentity bitmap atlasas

**Files:**
- Create: `resource-pack/assets/zoneout/textures/font/zone_identity.png`
- Modify: `resource-pack/assets/minecraft/font/default.json`

**Interfaces:**
- Consumes: Task 1 apibrėžtus `U+E300` ir tolesnius kodus.
- Produces: fiksuoto pločio profilio avatarą, du skirtukus ir grandine sujungtas custom ikonėles.

- [ ] **Step 1: Create a failing asset check**

Patikra turi reikalauti `zone_identity.png`, tikslių atlaso matmenų, font JSON providerio ir visų Task 1 kodų.

- [ ] **Step 2: Run check and confirm failure**

Run: `test -f .../zone_identity.png && jq -e ... default.json`
Expected: FAIL, nes atlaso ir providerio nėra.

- [ ] **Step 3: Generate the pixel-art atlas**

Nupiešti `ZONE_CORE` avatarą, horizontalias linijas, XP rutulį, `Z` monetą, tinklo mazgus, portalą ir keturių kadrų chronometrą. Visoms eilutės ikonoms skirti tą patį glyph plotį ir per jų centrą tęsti vienodo X žalios grandinės pikselius.

- [ ] **Step 4: Add the bitmap provider**

`default.json` pridėti `zoneout:font/zone_identity.png` providerį su `ascent` ir `height`, atitinkančiais maketo baseline.

- [ ] **Step 5: Run asset checks**

Expected: PNG egzistuoja, JSON validus, visi glyphų kodai atitinka Java konstantas.

### Task 3: Scoreboard profilio kortelės integracija

**Files:**
- Modify: `src/main/java/lt/zoneoutmc/scoreboard/ZoneScoreboardPlugin.java`
- Modify: `src/main/resources/config.yml`
- Modify: `src/main/resources/plugin.yml`
- Test: `src/test/java/lt/zoneoutmc/scoreboard/ZoneIdentityHudTest.java`

**Interfaces:**
- Consumes: `ZoneIdentityHud.glyph(...)`, žaidėjo vardą, ZonePermissions pilną rangą, lygį ir esamus XP duomenis.
- Produces: placeholderius `{identity_avatar}`, `{identity_divider}`, `{icon_xp}`, `{icon_coins}`, `{icon_online}`, `{icon_server}`, `{icon_playtime}`.

- [ ] **Step 1: Extend the failing test**

Testas reikalauja numatytųjų dviejų profilio eilučių ir visų naujų placeholderių šablono.

- [ ] **Step 2: Run and confirm expected failure**

Expected: FAIL dėl trūkstamo HUD šablono.

- [ ] **Step 3: Implement placeholders and config v5 migration**

Pridėti glyphų placeholderius ir pakeisti tik atpažintas senas numatytąsias eilutes. Naujame šablone naudoti baltą vardą, pilną spalvotą rangą, žalią lygį, skirtukus, custom ikonėles ir geltoną adresą.

- [ ] **Step 4: Run all Java tests**

Expected: `ZoneXpBarTest` ir `ZoneIdentityHudTest` PASS.

### Task 4: Build, pack and verify test release

**Files:**
- Modify: `build.sh`
- Modify: `README.md`
- Create: `ZoneScoreboard-v2.5.0-ZONE-IDENTITY-Paper26.2.jar`
- Create: `ZoneStatues-v2.5.0-ResourcePack.zip`
- Create: `ZoneScoreboard-v2.5.0-SOURCE.zip`

**Interfaces:**
- Consumes: Tasks 1–3 rezultatą.
- Produces: trys vartotojui skirti diegimo failai.

- [ ] **Step 1: Build the JAR and resource pack**

Paleisti `build.sh`, ZIP sukurti nuo resource pack šaknies.

- [ ] **Step 2: Verify deliverables**

Paleisti visus Java testus, `unzip -t` abiem archyvams, `jq` visiems JSON, `identify` PNG atlasams, patikrinti JAR `plugin.yml` versiją ir apskaičiuoti resource pack SHA1.

- [ ] **Step 3: Save deliverables**

Išsaugoti JAR, resource pack ir source ZIP, tada pateikti diegimo nuorodas bei SHA1.
