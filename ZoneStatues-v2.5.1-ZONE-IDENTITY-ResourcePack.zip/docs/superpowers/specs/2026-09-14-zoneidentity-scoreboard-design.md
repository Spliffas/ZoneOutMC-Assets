# ZoneIdentity scoreboard vidaus dizainas

## Tikslas

Minecraft standartinė sidebar lentelės forma, fonas, vieta ir išoriniai kampai
nekeičiami. Resource pack ir ZoneScoreboard keičia tik lentelės vidų, kad jis
žaidime kuo tiksliau atkartotų patvirtintą ZoneIdentity maketą.

## Patvirtintas išdėstymas

1. Viršuje rodomas `ZONEOUTMC`: `ZONE` ir `MC` neoninės žalios spalvos,
   `OUT` baltas.
2. Po antrašte yra plona pilkai žalia horizontali skiriamoji linija.
3. Toliau rodoma dviejų eilučių profilio kortelė:
   - kairėje – 12×12 pikselinis custom `Zone Avatar` glyphas;
   - pirmoje eilutėje – baltas žaidėjo vardas;
   - antroje – pilnas ZonePermissions rangas ir žalias žaidėjo lygis.
4. Po profiliu rodoma antra skiriamoji linija.
5. Toliau vienodu atstumu rodomos XP, monetų, prisijungusių žaidėjų, serverio
   ir žaidimo laiko eilutės.
6. Visos šių eilučių ikonėlės yra vienodo pločio. Į kiekvieną glyphą
   įpiešiamos viršutinė ir apatinė žalios energijos grandinės dalys, todėl
   žaidime jos vizualiai susijungia į vieną vertikalią liniją.
7. XP eilutė naudoja žaliai–žydrą rutuliuką ir esamą kapsulės formos juostą su
   maždaug kas keturias sekundes pereinančiu baltai–žydru blizgesiu.
8. Apačioje paliekamas geltonas `PLAY.ZONEOUTMC.LT`.

## Custom ikonėlės

- Profilis: tamsus Zone šalmas energijos žiede.
- Rangas: `Rank Core` emblema, ne standartinė karūna.
- XP: energijos rutulys.
- Monetos: auksinė moneta su `Z`.
- Prisijungę: trys sujungti tinklo mazgai.
- Serveris: žaliai–žydras portalas.
- Žaista: chronometras su animuojama rodykle.

Ikonėlės kuriamos kaip ryškus Minecraft pixel art be suliejimo. Resource pack
gali turėti didesnį šaltinio atlasą, tačiau žaidime glyphų dydžiai ir baseline
bus suvienodinti, kad tekstas prasidėtų toje pačioje vietoje.

## ZoneIdentity kosmetikos

Pirmoji tema yra `ZONE_CORE`. Profilio glypho kodas parenkamas kiekvienam
žaidėjui pagal išsaugotą temos ID. Duomenų struktūra iš karto leidžia vėliau
pridėti `INFERNO`, `FROST`, `VOID` ir sezonines temas nekeičiant scoreboard
išdėstymo.

Pirmoje versijoje temos pasirinkimas ir turėjimas saugomi atskirai nuo rango.
Rangas ir jo pilnas rodomas pavadinimas gaunami tiesiai iš ZonePermissions.
ZoneScoreboard nepriklauso nuo seno ZoneCore.

## Konfigūracija

YAML faile lieka keičiami tekstai, spalvos, eilučių tvarka, simbolių kodai,
animacijos greitis ir kosmetinių temų leidimai. Atnaujinimas migracijoje keičia
tik atpažintas numatytąsias senas eilutes, todėl naudotojo nesusiję pakeitimai
neperrašomi.

## Ribos

Minecraft sidebar išorė nekeičiama. Tikra dinamiška žaidėjo skin galva į
resource pack šriftą nekeliama; naudojamas custom Zone Avatar. Patvirtintas
vidaus išdėstymas taikomas Paper 26.2 ir projektuojamas pagal tą pačią GUI skalę,
kuria padaryta pateikta ekrano nuotrauka.

## Patikra

- Grynos glypho parinkimo ir animacijos funkcijos tikrinamos vienetiniais
  testais.
- Tikrinami font JSON kodai, PNG atlasų matmenys ir resource pack ZIP.
- Tikrinama JAR versija, konfigūracijos migracija ir ZonePermissions ryšys.
- Galutinis pikselių lygiavimas patvirtinamas naudotojo Paper 26.2 serveryje
  pagal žaidimo ekrano nuotrauką.
