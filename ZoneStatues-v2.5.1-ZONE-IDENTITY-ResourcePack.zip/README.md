# ZoneScoreboard v2.5.0 — ZoneIdentity HUD Preview

Ši bandomoji versija standartinio Minecraft sidebar viduje atkuria patvirtintą
ZoneIdentity maketą: dviejų eilučių profilio bloką su Zone Avatar, pilną rangą
ir lygį, horizontalius skirtukus bei vienodo pločio custom ikonėles. XP,
monetų, prisijungusių žaidėjų, serverio ir laiko ikonų centru eina vientisa
žalia energijos grandinė. Keturių kadrų chronometro rodyklė apsisuka maždaug
kas keturias sekundes.

Minecraft lentelės išorinis fonas ir forma nekeičiami. Tikras žaidėjo skinas
scoreboard šrifte nenaudojamas: profilio vietoje rodoma `ZONE_CORE` kosmetinė
Zone Avatar emblema. Po pirmo testo serveryje glyphų dydžiai ir baseline gali
būti tikslinami pagal pateiktą žaidimo ekrano nuotrauką.

XP eilutė naudoja custom žaliai–žydrą XP rutuliuką, o apačioje rodoma viena
vientisa 80 px kapsulės formos ZoneOut energijos juosta. Ji turi 17 užpildymo
būsenų ir aštuonių kadrų animaciją: siauras baltai–žydras blizgesys pereina
per užpildytą dalį, po to kelis kadrus juosta lieka rami. Esant numatytam
10 tick atnaujinimui visas ciklas kartojasi maždaug kas 4 sekundes.
Būtinas `ZoneStatues-v2.4.2-ResourcePack.zip` arba jo failų įtraukimas
į pagrindinį ZoneOutMC resource packą.

Nauja versija nebepriklauso nuo seno ZoneCore. Ji naudoja ZonePermissions API.
Visas eilučių tekstas, spalvos, simboliai ir tvarka keičiami `config.yml`.
Palaikomi ir senos v1.4.1 konfigūracijos placeholderiai, o Paper palaikomose
versijose dešinėje neberodomi raudoni eilučių numeriai.

Komanda: `/zscore reload`.

Papildomos komandos: `/zscore help`, `toggle`, `on`, `off`, `lines`, `title`,
`setline`, `addline`, `removeline`. Paper 26.2 `NumberFormat.blank()` tiesiogiai
paslepia raudonus eilučių numerius.

`{playtime}` rodo tikrą Minecraft žaidėjo statistiką formatu `2d 6h 14m`.

Kiekvienas žaidėjas turi atskirą scoreboard objektą, todėl vieno žaidėjo vardas,
rolė, ping ir laikas nebegali būti parodyti kitam žaidėjui.
