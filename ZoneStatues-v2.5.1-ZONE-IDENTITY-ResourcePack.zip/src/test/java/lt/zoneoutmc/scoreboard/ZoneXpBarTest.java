package lt.zoneoutmc.scoreboard;

public final class ZoneXpBarTest {
    public static void main(String[] args) {
        String empty = ZoneXpBar.render(0, 100, 0);
        require(empty.codePointCount(0, empty.length()) == 1,
                "Juosta turi būti vienas vientisas glyphas be seno rombo");
        require(empty.codePointAt(0) == ZoneXpBar.BAR_BASE,
                "Nulinis XP turi pasirinkti visiškai tuščią būseną");

        String half = ZoneXpBar.render(50, 100, 7);
        int halfGlyph = half.codePointAt(0);
        require(ZoneXpBar.FRAMES == 8,
                "Blizgesys turi kartotis kas aštuonis atnaujinimo kadrus");
        require(halfGlyph == ZoneXpBar.BAR_BASE + 7 * ZoneXpBar.STATES + 8,
                "50 procentų XP turi pasirinkti pusiau užpildytą aštuntą animacijos kadrą");

        String full = ZoneXpBar.render(100, 100, 8);
        int fullGlyph = full.codePointAt(0);
        require(fullGlyph == ZoneXpBar.BAR_BASE + 16,
                "Pilnas XP turi pasirinkti paskutinę užpildymo būseną");
    }

    private static void require(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
