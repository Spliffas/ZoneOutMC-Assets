package lt.zoneoutmc.scoreboard;

import java.util.HashSet;
import java.util.Set;

public final class ZoneIdentityHudTest {
    public static void main(String[] args) {
        Set<Integer> glyphs = new HashSet<>();
        for (ZoneIdentityHud.Part part : ZoneIdentityHud.Part.values()) {
            require(glyphs.add(ZoneIdentityHud.glyph(part, 0)),
                    "Kiekviena ZoneIdentity dalis privalo turėti atskirą bazinį glyphą");
        }

        int clock0 = ZoneIdentityHud.glyph(ZoneIdentityHud.Part.PLAYTIME, 0);
        int clock3 = ZoneIdentityHud.glyph(ZoneIdentityHud.Part.PLAYTIME, 3);
        int clock4 = ZoneIdentityHud.glyph(ZoneIdentityHud.Part.PLAYTIME, 4);
        require(clock3 == clock0 + 3, "Laikrodis turi keturis nuoseklius kadrus");
        require(clock4 == clock0, "Ketvirtas tickas turi pradėti naują laikrodžio ciklą");

        require(ZoneIdentityHud.glyph(ZoneIdentityHud.Part.AVATAR, 99) == 0xE120,
                "ZONE_CORE avataras pirmoje versijoje turi būti stabilus");
        require(ZoneIdentityHud.defaultLines().size() == 13,
                "HUD turi tilpti į trylika sidebar eilučių");
        require(ZoneIdentityHud.defaultLines().get(1).contains("{identity_avatar}"),
                "Pirmoje profilio eilutėje turi būti Zone Avatar");
        require(ZoneIdentityHud.defaultLines().get(2).contains("{rank_colored}")
                        && ZoneIdentityHud.defaultLines().get(2).contains("LVL {level}"),
                "Antroje profilio eilutėje turi būti rangas ir lygis");
        require(ZoneIdentityHud.defaultLines().get(5).contains("{identity_track}")
                        && ZoneIdentityHud.defaultLines().get(5).contains("{xp_bar}"),
                "XP juosta turi tęsti vertikalią energijos grandinę");

        require(ZoneIdentityHud.isLegacyLayout(java.util.List.of(
                        "&f♟ {player}", "&f{icon_xp} XP {xp}/{xp_max}", "&f{xp_bar}")),
                "Senas numatytasis HUD turi būti atpažintas migracijai");
        require(!ZoneIdentityHud.isLegacyLayout(java.util.List.of(
                        "&fMANO PROFILIS", "&f{xp_bar}")),
                "Naudotojo custom HUD negalima automatiškai perrašyti");
    }

    private static void require(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
