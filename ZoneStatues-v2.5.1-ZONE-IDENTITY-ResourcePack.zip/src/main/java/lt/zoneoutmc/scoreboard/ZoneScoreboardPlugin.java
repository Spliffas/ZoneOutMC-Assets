package lt.zoneoutmc.scoreboard;

import lt.zoneoutmc.permissions.PlayerProfile;
import lt.zoneoutmc.permissions.Role;
import lt.zoneoutmc.permissions.RoleCategory;
import lt.zoneoutmc.permissions.ZonePermissionsService;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import io.papermc.paper.scoreboard.numbers.NumberFormat;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.HashMap;
import java.io.File;
import java.io.IOException;
import org.bukkit.configuration.file.YamlConfiguration;

public final class ZoneScoreboardPlugin extends JavaPlugin {
    private ZonePermissionsService permissions;
    private BukkitTask updateTask;
    private final Map<UUID, Scoreboard> playerBoards = new HashMap<>();
    private File xpFile;
    private YamlConfiguration xpData;
    private int xpAnimationFrame;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        migrateConfig();
        xpFile = new File(getDataFolder(), "zone-xp.yml");
        xpData = YamlConfiguration.loadConfiguration(xpFile);
        permissions = getServer().getServicesManager().load(ZonePermissionsService.class);
        if (permissions == null) {
            getLogger().severe("ZonePermissions API nerasta. ZoneScoreboard išjungiamas.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        if (getCommand("zonescoreboard") != null) {
            getCommand("zonescoreboard").setExecutor((sender, command, label, args) -> command(sender, args));
            getCommand("zonescoreboard").setTabCompleter((sender, command, alias, args) -> complete(sender, args));
        }
        long period = Math.max(10L, getConfig().getLong("settings.update-ticks", 20L));
        updateTask = getServer().getScheduler().runTaskTimer(this, this::refreshAll, 1L, period);
        getLogger().info("ZoneScoreboard įjungtas ir prijungtas prie ZonePermissions.");
    }

    @Override
    public void onDisable() {
        if (updateTask != null) updateTask.cancel();
        saveXp();
        playerBoards.clear();
    }

    private boolean command(CommandSender sender, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            help(sender);
            return true;
        }
        if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
            if (!canEdit(sender)) {
                sender.sendMessage(color(getConfig().getString("messages.no-permission", "&cNeturi leidimo.")));
                return true;
            }
            reloadConfig();
            refreshAll();
            sender.sendMessage(color(getConfig().getString("messages.reloaded", "&aZoneScoreboard perkrautas.")));
            return true;
        }
        if (args.length >= 2 && args[0].equalsIgnoreCase("xp")) {
            if (!canEdit(sender)) { sender.sendMessage(color(getConfig().getString("messages.no-permission", "&cNeturi leidimo."))); return true; }
            if (args[1].equalsIgnoreCase("show")) {
                Player target = args.length >= 3 ? Bukkit.getPlayerExact(args[2]) : (sender instanceof Player p ? p : null);
                if (target == null) { sender.sendMessage(color("&cŽaidėjas nerastas arba naudok: /zscore xp show <žaidėjas>")); return true; }
                sender.sendMessage(color("&2&lZone&f&lOut&2&lMC &8◆ &7" + target.getName() + " &8| &7Lygis: &a" + zoneLevel(target.getUniqueId()) + " &8| &7XP: &a" + zoneXp(target.getUniqueId()) + "&7/&a" + xpNeeded(zoneLevel(target.getUniqueId()))));
                return true;
            }
            if (args.length < 4 || (!args[1].equalsIgnoreCase("add") && !args[1].equalsIgnoreCase("set"))) { sender.sendMessage(color("&7Naudok: &f/zscore xp add <žaidėjas> <kiekis> &7arba &f/zscore xp set <žaidėjas> <xp>")); return true; }
            Player target=Bukkit.getPlayerExact(args[2]); if(target==null){sender.sendMessage(color("&cŽaidėjas nerastas."));return true;}
            int amount; try{amount=Math.max(0,Integer.parseInt(args[3]));}catch(NumberFormatException ex){sender.sendMessage(color("&cXP turi būti skaičius."));return true;}
            int total=args[1].equalsIgnoreCase("add")?zoneXp(target.getUniqueId())+amount:amount; setZoneXp(target.getUniqueId(),total); refresh(target); sender.sendMessage(color("&a"+target.getName()+" XP: "+total)); return true;
        }
        if (sender instanceof Player player && args.length == 1 && args[0].equalsIgnoreCase("toggle")) {
            boolean hidden = hidden(player);
            setHidden(player, !hidden);
            sender.sendMessage(color(getConfig().getString(!hidden ? "messages.hidden" : "messages.shown",
                    !hidden ? "&7Scoreboard paslėptas." : "&aScoreboard parodytas.")));
            if (!hidden) removeBoard(player); else refresh(player);
            return true;
        }
        if (sender instanceof Player player && args.length == 1 && (args[0].equalsIgnoreCase("on") || args[0].equalsIgnoreCase("off"))) {
            boolean hide = args[0].equalsIgnoreCase("off");
            setHidden(player, hide);
            if (hide) removeBoard(player); else refresh(player);
            sender.sendMessage(color(getConfig().getString(hide ? "messages.hidden" : "messages.shown", hide ? "&7Scoreboard paslėptas." : "&aScoreboard parodytas.")));
            return true;
        }
        if (!canEdit(sender)) {
            sender.sendMessage(color(getConfig().getString("messages.no-permission", "&cNeturi leidimo.")));
            return true;
        }
        if (args.length >= 2 && args[0].equalsIgnoreCase("title")) {
            getConfig().set("scoreboard.title", join(args, 1)); saveConfig(); refreshAll();
            sender.sendMessage(color(getConfig().getString("messages.saved", "&aPakeitimas išsaugotas."))); return true;
        }
        if (args.length >= 3 && args[0].equalsIgnoreCase("setline")) {
            int index = number(args[1]); List<String> lines = new ArrayList<>(getConfig().getStringList("scoreboard.lines"));
            if (index < 1 || index > lines.size()) return invalidLine(sender, lines.size());
            lines.set(index - 1, join(args, 2)); saveLines(lines); sender.sendMessage(color(getConfig().getString("messages.saved", "&aPakeitimas išsaugotas."))); return true;
        }
        if (args.length >= 2 && args[0].equalsIgnoreCase("addline")) {
            List<String> lines = new ArrayList<>(getConfig().getStringList("scoreboard.lines")); lines.add(join(args, 1));
            saveLines(lines); sender.sendMessage(color(getConfig().getString("messages.saved", "&aPakeitimas išsaugotas."))); return true;
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("removeline")) {
            int index = number(args[1]); List<String> lines = new ArrayList<>(getConfig().getStringList("scoreboard.lines"));
            if (index < 1 || index > lines.size()) return invalidLine(sender, lines.size());
            lines.remove(index - 1); saveLines(lines); sender.sendMessage(color(getConfig().getString("messages.saved", "&aPakeitimas išsaugotas."))); return true;
        }
        if (args.length == 1 && args[0].equalsIgnoreCase("lines")) {
            List<String> lines = getConfig().getStringList("scoreboard.lines");
            sender.sendMessage(color("&2&lZone&f&lOut&2&lMC &8◆ &fScoreboard eilutės:"));
            for (int i = 0; i < lines.size(); i++) sender.sendMessage(color("&8" + (i + 1) + ". &r" + lines.get(i)));
            return true;
        }
        help(sender);
        return true;
    }

    private void refreshAll() {
        xpAnimationFrame++;
        playerBoards.keySet().removeIf(uuid -> Bukkit.getOnlinePlayers().stream().noneMatch(player -> player.getUniqueId().equals(uuid)));
        for (Player player : Bukkit.getOnlinePlayers()) refresh(player);
    }

    private void refresh(Player player) {
        if (hidden(player)) { removeBoard(player); return; }
        Scoreboard board = playerBoards.computeIfAbsent(player.getUniqueId(), ignored -> Bukkit.getScoreboardManager().getNewScoreboard());
        if (player.getScoreboard() != board) player.setScoreboard(board);
        Objective old = board.getObjective("zoneout");
        if (old != null) old.unregister();
        Objective objective = board.registerNewObjective("zoneout", "dummy", color(getConfig().getString("scoreboard.title", "&2&lZONE&f&lOUT&2&lMC")));
        objective.setDisplaySlot(DisplaySlot.SIDEBAR);
        objective.numberFormat(NumberFormat.blank());

        List<String> configured = getConfig().getStringList("scoreboard.lines");
        List<String> lines = configured == null ? List.of() : new ArrayList<>(configured);
        int score = lines.size();
        int unique = 0;
        for (String raw : lines) {
            String rendered = color(placeholders(raw, player));
            String entry = rendered + uniqueSuffix(unique++);
            objective.getScore(entry).setScore(score--);
        }
    }

    private String placeholders(String text, Player player) {
        Role primary = permissions.primaryRole(player.getUniqueId());
        PlayerProfile profile = permissions.profile(player.getUniqueId()).orElse(null);
        String roleColored = primary.color() + primary.displayName();
        return text.replace("{player}", player.getName())
                .replace("{role}", primary.displayName())
                .replace("{role_color}", primary.color())
                .replace("{rank}", primary.displayName())
                .replace("{rank_colored}", roleColored)
                .replace("{service}", roleName(profile, RoleCategory.SERVICE))
                .replace("{creator}", roleName(profile, RoleCategory.CREATOR))
                .replace("{status}", roleName(profile, RoleCategory.STATUS))
                .replace("{staff}", roleName(profile, RoleCategory.STAFF))
                .replace("{online}", Integer.toString(Bukkit.getOnlinePlayers().size()))
                .replace("{max}", Integer.toString(Bukkit.getMaxPlayers()))
                .replace("{ping}", ping(player))
                .replace("{level}", Integer.toString(zoneLevel(player.getUniqueId())))
                .replace("{xp}", Integer.toString(xpIntoLevel(player.getUniqueId())))
                .replace("{xp_max}", Integer.toString(xpNeeded(zoneLevel(player.getUniqueId()))))
                .replace("{coins}", getConfig().getString("temporary-values.coins", "0"))
                .replace("{server}", getConfig().getString("settings.server-name", "Minigames"))
                .replace("{servers}", getConfig().getString("settings.server-name", "Minigames"))
                .replace("{xp_needed}", getConfig().getString("temporary-values.xp-max", "100"))
                .replace("{xp_bar}", xpBar(player))
                .replace("{playtime}", playtime(player))
                .replace("{address}", getConfig().getString("settings.address", "play.zoneoutmc.lt"))
                .replace("{identity_avatar}", getConfig().getString("icons.identity-avatar", ZoneIdentityHud.character(ZoneIdentityHud.Part.AVATAR, 0)))
                .replace("{identity_indent}", getConfig().getString("icons.identity-indent", ZoneIdentityHud.character(ZoneIdentityHud.Part.INDENT, 0)))
                .replace("{identity_divider}", getConfig().getString("icons.identity-divider", ZoneIdentityHud.character(ZoneIdentityHud.Part.DIVIDER, 0)))
                .replace("{identity_track}", getConfig().getString("icons.identity-track", ZoneIdentityHud.character(ZoneIdentityHud.Part.TRACK, 0)))
                .replace("{icon_player}", getConfig().getString("icons.player", "♟"))
                .replace("{icon_rank}", getConfig().getString("icons.rank", "♛"))
                .replace("{icon_level}", getConfig().getString("icons.level", "★"))
                .replace("{icon_xp}", getConfig().getString("icons.xp", ZoneIdentityHud.character(ZoneIdentityHud.Part.XP, 0)))
                .replace("{icon_coins}", getConfig().getString("icons.coins", ZoneIdentityHud.character(ZoneIdentityHud.Part.COINS, 0)))
                .replace("{icon_online}", getConfig().getString("icons.online", ZoneIdentityHud.character(ZoneIdentityHud.Part.ONLINE, 0)))
                .replace("{icon_server}", getConfig().getString("icons.server", ZoneIdentityHud.character(ZoneIdentityHud.Part.SERVER, 0)))
                .replace("{icon_playtime}", ZoneIdentityHud.character(ZoneIdentityHud.Part.PLAYTIME, xpAnimationFrame / 2))
                .replace("{icon_address}", getConfig().getString("icons.address", "◆"));
    }

    private String roleName(PlayerProfile profile, RoleCategory category) {
        if (profile == null || profile.role(category) == null) return getConfig().getString("messages.none", "Nėra");
        return permissions.role(profile.role(category)).map(Role::displayName).orElse(getConfig().getString("messages.none", "Nėra"));
    }

    private String ping(Player player) {
        try { return String.valueOf(player.getClass().getMethod("getPing").invoke(player)); }
        catch (ReflectiveOperationException ignored) { return "0"; }
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private String playtime(Player player) {
        try {
            Class<? extends Enum> statisticClass = (Class<? extends Enum>) Class.forName("org.bukkit.Statistic");
            Object statistic;
            try { statistic = Enum.valueOf(statisticClass, "PLAY_ONE_MINUTE"); }
            catch (IllegalArgumentException ignored) { statistic = Enum.valueOf(statisticClass, "PLAY_ONE_TICK"); }
            int ticks = ((Number) player.getClass().getMethod("getStatistic", statisticClass).invoke(player, statistic)).intValue();
            long totalSeconds = Math.max(0L, ticks / 20L);
            long days = totalSeconds / 86400L;
            long hours = (totalSeconds % 86400L) / 3600L;
            long minutes = (totalSeconds % 3600L) / 60L;
            long seconds = totalSeconds % 60L;
            String d = getConfig().getString("playtime.day-suffix", "d");
            String h = getConfig().getString("playtime.hour-suffix", "h");
            String m = getConfig().getString("playtime.minute-suffix", "m");
            String s = getConfig().getString("playtime.second-suffix", "s");
            if (days > 0) return days + d + " " + hours + h + " " + minutes + m + " " + seconds + s;
            if (hours > 0) return hours + h + " " + minutes + m + " " + seconds + s;
            if (minutes > 0) return minutes + m + " " + seconds + s;
            return seconds + s;
        } catch (ReflectiveOperationException | IllegalArgumentException ignored) {
            return getConfig().getString("temporary-values.playtime", "0m");
        }
    }

    private int zoneXp(UUID uuid) { return xpData == null ? 0 : Math.max(0, xpData.getInt(uuid.toString(), 0)); }
    private void setZoneXp(UUID uuid, int value) { if (xpData != null) { xpData.set(uuid.toString(), Math.max(0, value)); saveXp(); } }
    private int xpNeeded(int level) { return 100 + Math.max(0, level - 1) * 25; }
    private int zoneLevel(UUID uuid) { int total=zoneXp(uuid), level=1; while(total>=xpNeeded(level)){total-=xpNeeded(level);level++;} return level; }
    private int xpIntoLevel(UUID uuid) { int total=zoneXp(uuid), level=1; while(total>=xpNeeded(level)){total-=xpNeeded(level);level++;} return total; }
    private String xpBar(Player player) {
        int needed = Math.max(1, xpNeeded(zoneLevel(player.getUniqueId())));
        return ZoneXpBar.render(xpIntoLevel(player.getUniqueId()), needed, xpAnimationFrame);
    }
    private void saveXp() { if (xpData != null && xpFile != null) try { xpData.save(xpFile); } catch (IOException ex) { getLogger().warning("Nepavyko išsaugoti ZoneXP: " + ex.getMessage()); } }

    private void migrateConfig() {
        int version = getConfig().getInt("config-version", 0);
        if (version >= 2) {
            if (version < 5) {
                getConfig().set("config-version", 5);
                getConfig().set("settings.update-ticks", 10);
                getConfig().set("icons.identity-avatar", ZoneIdentityHud.character(ZoneIdentityHud.Part.AVATAR, 0));
                getConfig().set("icons.identity-indent", ZoneIdentityHud.character(ZoneIdentityHud.Part.INDENT, 0));
                getConfig().set("icons.identity-divider", ZoneIdentityHud.character(ZoneIdentityHud.Part.DIVIDER, 0));
                getConfig().set("icons.identity-track", ZoneIdentityHud.character(ZoneIdentityHud.Part.TRACK, 0));
                getConfig().set("icons.xp", ZoneIdentityHud.character(ZoneIdentityHud.Part.XP, 0));
                getConfig().set("icons.coins", ZoneIdentityHud.character(ZoneIdentityHud.Part.COINS, 0));
                getConfig().set("icons.online", ZoneIdentityHud.character(ZoneIdentityHud.Part.ONLINE, 0));
                getConfig().set("icons.server", ZoneIdentityHud.character(ZoneIdentityHud.Part.SERVER, 0));
            }
            if (getConfig().getInt("temporary-values.xp-bar-length", 0) <= 0) {
                getConfig().set("temporary-values.xp-bar-length", 20);
                getConfig().set("temporary-values.xp-bar-filled", "&a|");
                getConfig().set("temporary-values.xp-bar-empty", "&8|");
                saveConfig();
            }
            List<String> existing = new ArrayList<>(getConfig().getStringList("scoreboard.lines"));
            boolean lineChanged = false;
            for (int i=0;i<existing.size();i++) {
                String line=existing.get(i);
                if (line.equals("&a||||||||||") || line.contains("{xp_bar}")) {
                    if (!line.equals("&f{xp_bar}")) { existing.set(i, "&f{xp_bar}"); lineChanged=true; }
                }
                if (line.contains("{xp}") && line.contains("{xp_max}")) {
                    String xpLine = "&f{icon_xp} &7XP &8• &a{xp} &7/ &f{xp_max}";
                    if (!line.equals(xpLine)) { existing.set(i, xpLine); lineChanged=true; }
                }
            }
            if (version < 5 && ZoneIdentityHud.isLegacyLayout(existing)) {
                existing = new ArrayList<>(ZoneIdentityHud.defaultLines());
                lineChanged = true;
            }
            if (lineChanged) { getConfig().set("scoreboard.lines", existing); saveConfig(); }
            if ("Lobby".equalsIgnoreCase(getConfig().getString("settings.server-name", "Lobby"))) {
                getConfig().set("settings.server-name", "Minigames");
                saveConfig();
            }
            saveConfig();
            return;
        }
        getConfig().set("config-version", 5);
        getConfig().set("settings.update-ticks", 10);
        if ("Lobby".equalsIgnoreCase(getConfig().getString("settings.server-name", "Lobby"))) {
            getConfig().set("settings.server-name", "Minigames");
        }
        getConfig().set("settings.update-ticks", 10);
        getConfig().set("scoreboard.lines", ZoneIdentityHud.defaultLines());
        getConfig().set("temporary-values.xp-bar-filled", "&a|");
        getConfig().set("temporary-values.xp-bar-empty", "&8|");
        getConfig().set("temporary-values.xp-bar-length", 20);
        saveConfig();
    }

    private String uniqueSuffix(int index) {
        char code = "0123456789abcdefklmnor".charAt(index % 22);
        return "§" + code + "§r";
    }

    private boolean canEdit(CommandSender sender) { return !(sender instanceof Player player) || permissions.hasPermission(player.getUniqueId(), "zone.owner"); }
    private boolean hidden(Player player) { return getConfig().getStringList("hidden-players").contains(player.getUniqueId().toString()); }
    private void setHidden(Player player, boolean hidden) {
        List<String> values = new ArrayList<>(getConfig().getStringList("hidden-players"));
        values.remove(player.getUniqueId().toString()); if (hidden) values.add(player.getUniqueId().toString());
        getConfig().set("hidden-players", values); saveConfig();
    }
    private void removeBoard(Player player) {
        Scoreboard board = playerBoards.get(player.getUniqueId());
        if (board == null) return;
        Objective objective = board.getObjective("zoneout"); if (objective != null) objective.unregister();
    }
    private void saveLines(List<String> lines) { getConfig().set("scoreboard.lines", lines); saveConfig(); refreshAll(); }
    private int number(String value) { try { return Integer.parseInt(value); } catch (NumberFormatException ignored) { return -1; } }
    private String join(String[] args, int start) { return String.join(" ", java.util.Arrays.copyOfRange(args, start, args.length)); }
    private boolean invalidLine(CommandSender sender, int max) { sender.sendMessage(color("&cEilutės numeris turi būti nuo 1 iki " + max + ".")); return true; }
    private void help(CommandSender sender) {
        for (String line : getConfig().getStringList("messages.help")) sender.sendMessage(color(line));
    }
    private List<String> complete(CommandSender sender, String[] args) {
        if (args.length != 1) return List.of();
        List<String> values = new ArrayList<>(List.of("help", "toggle", "on", "off"));
        if (canEdit(sender)) values.addAll(List.of("reload", "lines", "title", "setline", "addline", "removeline"));
        String prefix = args[0].toLowerCase(Locale.ROOT);
        return values.stream().filter(value -> value.startsWith(prefix)).sorted().toList();
    }

    private String color(String text) {
        return text == null ? "" : text.replace('&', '§');
    }
}
