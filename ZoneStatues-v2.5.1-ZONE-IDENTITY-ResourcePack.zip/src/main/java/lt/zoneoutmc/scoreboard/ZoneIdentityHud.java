package lt.zoneoutmc.scoreboard;

import java.util.List;

final class ZoneIdentityHud {
    enum Part {
        AVATAR(0xE120, 1),
        INDENT(0xE121, 1),
        DIVIDER(0xE122, 1),
        XP(0xE123, 1),
        TRACK(0xE124, 1),
        COINS(0xE125, 1),
        ONLINE(0xE126, 1),
        SERVER(0xE127, 1),
        PLAYTIME(0xE128, 4);

        private final int base;
        private final int frames;

        Part(int base, int frames) {
            this.base = base;
            this.frames = frames;
        }
    }

    private ZoneIdentityHud() {}

    static int glyph(Part part, int frame) {
        return part.base + Math.floorMod(frame, part.frames);
    }

    static String character(Part part, int frame) {
        return new String(Character.toChars(glyph(part, frame)));
    }

    static List<String> defaultLines() {
        return List.of(
                "&f{identity_divider}",
                "&f{identity_avatar} &f{player}",
                "&f{identity_indent}&c&l{rank_colored} &8| &aLVL {level}",
                "&f{identity_divider}",
                "&f{icon_xp} &7XP &8• &a{xp} &7/ &f{xp_max}",
                "&f{identity_track}{xp_bar}",
                "&f{identity_divider}",
                "&f{icon_coins} &7MONETOS &8• &a{coins}",
                "&f{icon_online} &7PRISIJUNGĘ &8• &a{online} &7/ &f{max}",
                "&f{icon_server} &7SERVERIS &8• &e&l{server}",
                "&f{icon_playtime} &7ŽAISTA &8• &a{playtime}",
                "&f{identity_divider}",
                "&e&lPLAY.ZONEOUTMC.LT"
        );
    }

    static boolean isLegacyLayout(List<String> lines) {
        boolean defaultPlayer = lines.stream().anyMatch(line ->
                line.contains("{player}") && (line.contains("♟") || line.contains("{icon_player}")));
        boolean xpNumbers = lines.stream().anyMatch(line ->
                line.contains("{xp}") && line.contains("{xp_max}"));
        boolean xpBar = lines.stream().anyMatch(line -> line.contains("{xp_bar}"));
        return defaultPlayer && xpNumbers && xpBar;
    }
}
