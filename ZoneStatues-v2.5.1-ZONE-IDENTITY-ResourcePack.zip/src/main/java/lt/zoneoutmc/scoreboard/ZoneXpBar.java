package lt.zoneoutmc.scoreboard;

final class ZoneXpBar {
    static final int BAR_BASE = 0xE200;
    static final int STATES = 17;
    static final int FRAMES = 8;

    private ZoneXpBar() {}

    static String render(int xp, int needed, int animationFrame) {
        int safeNeeded = Math.max(1, needed);
        int state = Math.max(0, Math.min(STATES - 1,
                (int) Math.round(Math.max(0, xp) * (STATES - 1.0) / safeNeeded)));
        int frame = Math.floorMod(animationFrame, FRAMES);
        return new StringBuilder().appendCodePoint(BAR_BASE + frame * STATES + state).toString();
    }
}
