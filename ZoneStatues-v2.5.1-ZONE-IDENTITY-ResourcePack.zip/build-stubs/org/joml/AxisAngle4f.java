package org.joml;
public class AxisAngle4f { public AxisAngle4f(){} }
