package org.bukkit;
import java.util.List;
import java.util.UUID;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.block.data.BlockData;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.command.CommandMap;
import org.bukkit.command.CommandSender;
import org.bukkit.scoreboard.ScoreboardManager;
public final class Bukkit {
  public static World getWorld(String name){return null;}
  public static List<World> getWorlds(){return null;}
  public static Entity getEntity(UUID id){return null;}
  public static java.util.Collection<? extends Player> getOnlinePlayers(){return null;}
  public static Player getPlayerExact(String name){return null;}
  public static BlockData createBlockData(String value){return null;}
  public static Inventory createInventory(InventoryHolder holder,int size,String title){return null;}
  public static CommandMap getCommandMap(){return null;}
  public static CommandSender getConsoleSender(){return null;}
  public static boolean dispatchCommand(CommandSender sender,String command){return false;}
  public static int getMaxPlayers(){return 0;}
  public static int broadcastMessage(String message){return 0;}
  public static ScoreboardManager getScoreboardManager(){return null;}
}
