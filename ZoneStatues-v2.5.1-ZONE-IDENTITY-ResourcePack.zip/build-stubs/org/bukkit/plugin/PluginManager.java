package org.bukkit.plugin;
import org.bukkit.event.Listener;
public interface PluginManager { void disablePlugin(Plugin p); void registerEvents(Listener listener, Plugin plugin); }
