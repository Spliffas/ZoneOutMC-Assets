package org.bukkit;
public enum Material { AIR, LIGHT }
