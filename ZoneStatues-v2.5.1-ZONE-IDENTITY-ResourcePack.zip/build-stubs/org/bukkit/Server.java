package org.bukkit;
import java.util.List;
import java.util.UUID;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.PluginManager;
import org.bukkit.scheduler.BukkitScheduler;
import org.bukkit.plugin.messaging.Messenger;
import org.bukkit.plugin.ServicesManager;
public interface Server {
  World getWorld(String name); List<World> getWorlds(); Entity getEntity(UUID id);
  BukkitScheduler getScheduler(); PluginManager getPluginManager();
  Messenger getMessenger();
  ServicesManager getServicesManager();
  java.util.Collection<? extends Player> getOnlinePlayers(); int getMaxPlayers();
}
