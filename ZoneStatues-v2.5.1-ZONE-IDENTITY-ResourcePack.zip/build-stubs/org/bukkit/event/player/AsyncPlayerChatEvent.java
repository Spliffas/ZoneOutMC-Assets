package org.bukkit.event.player;
import org.bukkit.entity.Player;
public class AsyncPlayerChatEvent {
  public Player getPlayer(){return null;}
  public void setFormat(String format){}
}
