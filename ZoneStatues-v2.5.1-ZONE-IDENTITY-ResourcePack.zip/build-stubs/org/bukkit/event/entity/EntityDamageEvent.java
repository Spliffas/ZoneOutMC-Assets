package org.bukkit.event.entity;
import org.bukkit.entity.Entity;
public class EntityDamageEvent {
  public Entity getEntity(){return null;} public void setCancelled(boolean cancelled){}
}
