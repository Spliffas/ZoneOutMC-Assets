package org.bukkit.entity;
import org.bukkit.block.data.BlockData;
public interface BlockDisplay extends Display { void setBlock(BlockData block); }
