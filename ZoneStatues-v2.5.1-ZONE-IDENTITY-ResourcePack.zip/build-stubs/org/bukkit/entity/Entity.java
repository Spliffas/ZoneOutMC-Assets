package org.bukkit.entity;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Location;
public interface Entity {
  boolean addScoreboardTag(String t); void setPersistent(boolean p); UUID getUniqueId(); void remove();
  Set<String> getScoreboardTags(); boolean teleport(Location l);
  boolean addPassenger(Entity entity);
}
