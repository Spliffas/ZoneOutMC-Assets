package org.bukkit.entity;
public interface TextDisplay extends Display {
  enum TextAlignment { LEFT, CENTER, RIGHT }
  void setText(String t); void setAlignment(TextAlignment a); void setDefaultBackground(boolean b);
  void setShadowed(boolean b); void setSeeThrough(boolean b); void setLineWidth(int w);
}
