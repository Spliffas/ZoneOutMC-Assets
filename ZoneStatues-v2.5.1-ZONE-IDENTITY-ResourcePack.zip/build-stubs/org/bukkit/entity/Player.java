package org.bukkit.entity;
import org.bukkit.Location;
import org.bukkit.command.CommandSender;
import org.bukkit.Server;
import org.bukkit.World;
import org.bukkit.plugin.Plugin;
import org.bukkit.inventory.Inventory;
import org.bukkit.permissions.PermissionAttachment;
import org.bukkit.scoreboard.Scoreboard;
import java.util.UUID;
public interface Player extends Entity, CommandSender {
  Location getLocation(); String getName(); String getDisplayName(); World getWorld(); Server getServer();
  void setDisplayName(String name); void setPlayerListName(String name);
  void hideEntity(Plugin plugin, Entity entity); void showEntity(Plugin plugin, Entity entity);
  boolean isInsideVehicle(); boolean leaveVehicle();
  void openInventory(Inventory inventory);
  UUID getUniqueId(); boolean performCommand(String command);
  PermissionAttachment addAttachment(Plugin plugin); void removeAttachment(PermissionAttachment attachment);
  Scoreboard getScoreboard(); void setScoreboard(Scoreboard scoreboard);
  void playSound(Location location,String sound,float volume,float pitch);
  void sendTitle(String title,String subtitle,int fadeIn,int stay,int fadeOut);
  void sendPluginMessage(Plugin plugin,String channel,byte[] message);
  Spigot spigot();
  class Spigot { public void sendMessage(net.md_5.bungee.api.chat.BaseComponent... components){} }
}
