package org.bukkit.entity;
public interface ArmorStand extends Entity {
  void setInvisible(boolean value); void setGravity(boolean value); void setMarker(boolean value); void setSmall(boolean value);
  void setRotation(float yaw, float pitch);
}
