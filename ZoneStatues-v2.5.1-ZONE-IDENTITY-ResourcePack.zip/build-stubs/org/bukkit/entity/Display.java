package org.bukkit.entity;
public interface Display extends Entity {
  enum Billboard { FIXED, VERTICAL, HORIZONTAL, CENTER }
  void setBillboard(Billboard b); void setViewRange(float r);
  void setTransformation(org.bukkit.util.Transformation transformation);
}
