package org.bukkit.inventory;
public interface Inventory {}
