package org.bukkit.command;
public interface CommandSender { boolean hasPermission(String p); void sendMessage(String m); String getName(); }
