package org.bukkit.command;
public interface CommandMap { boolean register(String fallbackPrefix, Command command); }
