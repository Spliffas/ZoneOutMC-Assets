package org.bukkit.command;
import java.util.List;
public abstract class Command {
  protected Command(String name){}
  public Command setAliases(List<String> aliases){return this;} public Command setDescription(String description){return this;}
  public boolean unregister(CommandMap map){return false;}
  public abstract boolean execute(CommandSender sender,String label,String[] args);
}
