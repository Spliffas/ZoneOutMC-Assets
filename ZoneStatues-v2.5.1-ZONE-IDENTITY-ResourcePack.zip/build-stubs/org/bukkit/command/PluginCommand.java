package org.bukkit.command;
public class PluginCommand extends Command {
  public PluginCommand(){super("");}
  public void setExecutor(CommandExecutor e){} public void setTabCompleter(TabCompleter t){}
  public boolean execute(CommandSender s,String l,String[] a){return false;}
}
