package org.bukkit.configuration.file;
import java.util.List;
import org.bukkit.configuration.ConfigurationSection;
public class FileConfiguration {
  public boolean getBoolean(String p){return false;} public boolean getBoolean(String p,boolean d){return d;}
  public int getInt(String p,int d){return d;} public long getLong(String p,long d){return d;}
  public double getDouble(String p){return 0;} public double getDouble(String p,double d){return d;}
  public String getString(String p){return null;} public String getString(String p,String d){return d;}
  public List<String> getStringList(String p){return null;} public List<java.util.Map<?, ?>> getMapList(String p){return null;} public void set(String p,Object v){}
  public ConfigurationSection getConfigurationSection(String path){return null;}
}
