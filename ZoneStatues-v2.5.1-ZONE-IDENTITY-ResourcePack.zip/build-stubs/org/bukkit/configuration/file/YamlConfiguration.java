package org.bukkit.configuration.file;
import java.io.File;
import java.io.IOException;
public class YamlConfiguration extends FileConfiguration {
  public static YamlConfiguration loadConfiguration(File f){return null;} public void save(File f)throws IOException{}
}
