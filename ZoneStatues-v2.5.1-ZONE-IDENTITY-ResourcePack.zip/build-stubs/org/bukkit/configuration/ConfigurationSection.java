package org.bukkit.configuration;
import java.util.List;
import java.util.Set;
public interface ConfigurationSection {
  Set<String> getKeys(boolean deep);
  ConfigurationSection getConfigurationSection(String path);
  boolean getBoolean(String path,boolean fallback);
  int getInt(String path,int fallback);
  String getString(String path,String fallback);
  List<String> getStringList(String path);
}
