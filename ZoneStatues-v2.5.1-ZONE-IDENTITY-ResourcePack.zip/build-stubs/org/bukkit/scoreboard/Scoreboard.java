package org.bukkit.scoreboard;
public interface Scoreboard {
  Objective getObjective(String name);
  Objective registerNewObjective(String name,String criteria,String displayName);
}
