package org.bukkit.scoreboard;
public interface Objective { void setDisplaySlot(DisplaySlot slot); Score getScore(String entry); void unregister(); void numberFormat(io.papermc.paper.scoreboard.numbers.NumberFormat format); }
