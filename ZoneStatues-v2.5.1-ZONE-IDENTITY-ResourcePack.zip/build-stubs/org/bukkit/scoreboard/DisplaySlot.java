package org.bukkit.scoreboard;
public enum DisplaySlot { SIDEBAR, PLAYER_LIST, BELOW_NAME }
