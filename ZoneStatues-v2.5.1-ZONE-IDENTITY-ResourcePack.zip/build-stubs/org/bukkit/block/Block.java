package org.bukkit.block;
import org.bukkit.Material;
import org.bukkit.block.data.BlockData;
public interface Block {
  Material getType(); void setType(Material material, boolean physics); void setBlockData(BlockData data, boolean physics);
}
