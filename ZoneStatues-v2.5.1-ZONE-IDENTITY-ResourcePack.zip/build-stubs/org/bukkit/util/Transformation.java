package org.bukkit.util;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;
public class Transformation {
  public Transformation(Vector3f translation, AxisAngle4f leftRotation, Vector3f scale, AxisAngle4f rightRotation) {}
}
