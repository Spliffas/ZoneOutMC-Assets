package org.bukkit;
import java.util.Collection;
import java.util.function.Consumer;
import org.bukkit.entity.Entity;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
public interface World {
  String getName(); <T extends Entity> T spawn(Location l,Class<T> c,Consumer<? super T> f);
  <T extends Entity> Collection<T> getEntitiesByClass(Class<T> c);
  Block getBlockAt(int x,int y,int z); long getTime();
  java.util.List<Player> getPlayers();
}
