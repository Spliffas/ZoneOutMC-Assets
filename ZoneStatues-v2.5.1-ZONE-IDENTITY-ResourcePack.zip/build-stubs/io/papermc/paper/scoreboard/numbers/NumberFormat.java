package io.papermc.paper.scoreboard.numbers;
public interface NumberFormat { static NumberFormat blank(){return null;} }
