package net.md_5.bungee.api.chat;
public class ComponentBuilder {
  public ComponentBuilder(String text){}
  public BaseComponent[] create(){return null;}
}
