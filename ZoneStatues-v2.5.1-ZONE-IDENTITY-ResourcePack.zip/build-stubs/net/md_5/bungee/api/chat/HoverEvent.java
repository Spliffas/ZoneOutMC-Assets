package net.md_5.bungee.api.chat;
public class HoverEvent {
  public enum Action { SHOW_TEXT }
  public HoverEvent(Action action,BaseComponent[] value){}
}
