package net.md_5.bungee.api.chat;
public abstract class BaseComponent {
  public void setHoverEvent(HoverEvent event){}
  public void setClickEvent(ClickEvent event){}
}
