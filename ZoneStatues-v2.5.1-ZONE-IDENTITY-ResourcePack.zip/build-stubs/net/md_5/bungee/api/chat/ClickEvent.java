package net.md_5.bungee.api.chat;
public class ClickEvent {
  public enum Action { RUN_COMMAND }
  public ClickEvent(Action action,String value){}
}
