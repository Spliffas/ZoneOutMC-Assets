package net.md_5.bungee.api.chat;
public class TextComponent extends BaseComponent {
  public TextComponent(BaseComponent... components){}
  public static BaseComponent[] fromLegacyText(String text){return null;}
}
