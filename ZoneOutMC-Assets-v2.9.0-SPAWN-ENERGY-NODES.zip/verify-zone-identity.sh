#!/usr/bin/env bash
set -euo pipefail
pack_dir="$(cd "$(dirname "$0")" && pwd)"
font="$pack_dir/assets/minecraft/font/default.json"
for name in avatar xp coins online server clock0 clock1 clock2 clock3 rank level; do
  file="$pack_dir/assets/zoneout/textures/font/zone_identity_${name}.png"
  test -f "$file"
  test "$(identify -format '%wx%h' "$file")" = "12x12"
done
test -f "$pack_dir/assets/zoneout/textures/font/zone_identity_divider.png"
test "$(identify -format '%wx%h' "$pack_dir/assets/zoneout/textures/font/zone_identity_divider.png")" = "96x8"
jq -e '[.providers[] | select(.type == "bitmap" and .file == "zoneout:font/zone_identity_divider.png" and .chars == ["\ue122"])] | length == 1' "$font" >/dev/null
jq -e '[.providers[] | select(.type == "bitmap" and .file == "zoneout:font/zone_identity_avatar.png" and .chars == ["\ue120"])] | length == 1' "$font" >/dev/null
jq -e '[.providers[] | select(.type == "bitmap" and .file == "zoneout:font/zone_identity_xp.png" and .chars == ["\ue123"])] | length == 1' "$font" >/dev/null
